package com.jsp.BookStoreMngtSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreMngtSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
