package com.jsp.BookStoreMngtSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStoreMngtSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreMngtSystemApplication.class, args);
	}

}
