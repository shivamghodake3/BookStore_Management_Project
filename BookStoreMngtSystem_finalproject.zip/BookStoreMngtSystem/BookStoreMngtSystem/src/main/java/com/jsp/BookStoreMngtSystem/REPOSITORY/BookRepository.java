package com.jsp.BookStoreMngtSystem.REPOSITORY; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jsp.BookStoreMngtSystem.DTO.BookStore;


public interface BookRepository extends JpaRepository<BookStore, Long>{

	@Query("select b from BookStore b where b.title=?1")
	public List<BookStore> getBookByTitle(String title);
	
	@Query("select b from BookStore b where b.price>150")
	public List<BookStore> getBookByPrice();
}
