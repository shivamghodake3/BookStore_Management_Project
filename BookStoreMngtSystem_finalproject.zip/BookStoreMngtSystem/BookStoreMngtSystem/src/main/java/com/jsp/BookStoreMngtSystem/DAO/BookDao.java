package com.jsp.BookStoreMngtSystem.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.BookStoreMngtSystem.DTO.BookStore;
import com.jsp.BookStoreMngtSystem.REPOSITORY.BookRepository;

@Repository //to perform database operations
public class BookDao {

	@Autowired
	BookRepository repository;
	
	//to insert book object in db
	public BookStore insertBook(BookStore book) {
		return repository.save(book);
	}
	
	//to Retrieves all books from the database.
	public List<BookStore> getAllBooks(){
		return repository.findAll();
	}
	
	//to Retrieves a book by its id.
	public BookStore getBookById(long id) {
		Optional<BookStore> opt= repository.findById(id);
		if(opt.isPresent()) {
			return opt.get();
		}
		else {
			return null;
		}
	}
	
	//to Updates the book information in the database.--->title, publisher, price, quantity
	public BookStore updateBookById(long id,String newTitle,String newPublisher,double newPrice,int newQuantity) {
		BookStore b=getBookById(id);
		if(b!=null) {
			b.setTitle(newTitle);
			b.setPublisher(newPublisher);
			b.setPrice(newPrice);
			b.setQuantity(newQuantity);
			repository.save(b);
			
			return b;
		}
		else {
			return null;
		}
	}
	
	//to Deletes a book by its id.
	public String deleteBookById(long id) {
		BookStore b=getBookById(id);
		if(b!=null) {
			repository.delete(b);
			return "Book deleted successfully";
		}
		else {
			return "could not delete the requested Book .ID not found";
		}
	}
	
	//retrive a Book by title
	public List<BookStore> getBookByTitle(String title){
		return repository.getBookByTitle(title);
	}
	
	// retrive all books whose price is greater than 150rs
	public List<BookStore> getBookByprice(){
		return repository.getBookByPrice();
	}
}
