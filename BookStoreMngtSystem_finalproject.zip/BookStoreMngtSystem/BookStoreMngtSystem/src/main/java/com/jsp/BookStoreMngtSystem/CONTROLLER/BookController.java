package com.jsp.BookStoreMngtSystem.CONTROLLER;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.BookStoreMngtSystem.DAO.BookDao;
import com.jsp.BookStoreMngtSystem.DTO.BookStore;

@RestController
public class BookController {

	@Autowired
	BookDao dao;
	
	//REST API TO INSERT BOOK OBJECT INTO DB
	@PostMapping("/book")
	public BookStore addBook(@RequestBody BookStore book) {
		return dao.insertBook(book);
	}
	
	//Rest api to get all books
	@GetMapping("/book")
	public List<BookStore> getAllBooks(){
		return dao.getAllBooks();
	}
	
	//Rest api to search and get one book details based on id
	@GetMapping("/byid")
	public BookStore getBookById(@RequestParam long bid) {
		return dao.getBookById(bid);
	}
	
	//REST API to update title,publisher, price, quantity based on id
	@PutMapping("/update")
	public BookStore updateBookById(@RequestParam long id,@RequestParam String title,@RequestParam String publisher,@RequestParam double price,@RequestParam int quantity) {
		return dao.updateBookById(id, title, publisher, price, quantity);
	}
	
	//RESTAPI to delete a book from db
	@DeleteMapping("/delete")
		public String deleteBookById(@RequestParam long id) {
			return dao.deleteBookById(id);
		}
	
	//REST API to get a book based on title
	@GetMapping("/title")
	public List<BookStore> getBookByTitle(@RequestParam String title) {
		return dao.getBookByTitle(title);
	}
	
	////REST API to get all books whose price is greater than 150rs
	@GetMapping("/price")
	public List<BookStore> getBookByPrice(){
		return dao.getBookByprice();
	}
}
